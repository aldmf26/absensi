<?php

namespace App\Http\Controllers;

use App\Models\Absensi_Agrilaras;
use App\Models\Karyawan;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AbsensiAgrilaras extends Controller
{
    public function detail_agrilaras(Request $request)
    {
        $id_departemen = $request->id_departemen;
        $id_user = Auth::user()->id;

        if (empty($request->bulan)) {
           $bulan = date('m');
        } else {
            $bulan = $request->bulan;
        }
        if (empty($request->tahun)) {
           $tahun = date('Y');
        } else {
            $tahun = $request->tahun;
        }

        // dd($tahun);
        
        // select('absensi_agrilaras.*','karyawan.*')
        // ->join('karyawan','absensi_agrilaras.id_karyawan', '=', 'karyawan.id_karyawan')->orderBy('id', 'desc'),
        $data = [
            'title' => 'Absensi',
            'absensi' => Absensi_Agrilaras::select('absensi_agrilaras.*', 'karyawan.nama_karyawan', 'users.nama')->join('karyawan', 'absensi_agrilaras.id_karyawan', '=', 'karyawan.id_karyawan')->join('users', 'absensi_agrilaras.admin', '=', 'users.id')->where('absensi_agrilaras.tanggal_masuk', 'LIKE', '%'.'2022-03-01'.'%')->orderBy('id', 'desc')->get(),
            'karyawan' => Karyawan::where('id_departemen', 'LIKE', '%'.'4'.'%')->get(),
            'tahun' => Absensi_Agrilaras::all(),
            'bulan' => $bulan,
            'tahun_2' => $tahun,
            's_tahun' => DB::select(DB::raw("SELECT YEAR(a.tanggal_masuk) as tahun FROM absensi_agrilaras as a group by YEAR(a.tanggal_masuk)")),
            'status' => Status::all(),
            'id_departemen' => $id_departemen
        ];

        return view('absensi_agrilaras.absensi_agrilaras_detail',['id_departemen' => 4],$data);
    }

    public function ubah_bulan(Request $request){
        dd($request->bulan);
    }

    public function input_agrilaras(Request $request)
    {
       $data = [
        'id_karyawan' => $request->id_karyawan,
        'status' => $request->status,
        'tanggal_masuk' => $request->tanggal,
        'admin' => Auth::user()->id,
        // 'admin' => $request->admin,
       ];
       

       Absensi_Agrilaras::create($data);
       return true;

    }

    public function delete_agrilaras(Request $request)
    {
        Absensi_Agrilaras::where('id',$request->id_absen)->delete();
        return true;
    }
}
